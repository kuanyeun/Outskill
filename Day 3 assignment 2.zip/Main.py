import streamlit as st
from datetime import datetime
from open_ai_oss import chat

# ----------------------------
# Page config
# ----------------------------
st.set_page_config(
    page_title="Demo Assistant",
    page_icon="🚀",
    layout="wide",
)

# ----------------------------
# Session state initialization
# ----------------------------
if "messages" not in st.session_state:
    st.session_state.messages = []

if "start_time" not in st.session_state:
    st.session_state.start_time = datetime.now()

if "assistant_name" not in st.session_state:
    st.session_state.assistant_name = "Demo Assistant"

if "response_style" not in st.session_state:
    st.session_state.response_style = "Friendly"

if "show_timestamps" not in st.session_state:
    st.session_state.show_timestamps = True

if "max_history" not in st.session_state:
    st.session_state.max_history = 31


# ----------------------------
# Sidebar – Configuration
# ----------------------------
with st.sidebar:
    st.title("⚙️ Configuration")

    st.subheader("Assistant Settings")
    st.session_state.assistant_name = st.text_input(
        "Assistant Name",
        st.session_state.assistant_name,
    )

    st.session_state.response_style = st.selectbox(
        "Response Style",
        ["Friendly", "Professional", "Concise"],
        index=["Friendly", "Professional", "Concise"].index(
            st.session_state.response_style
        ),
    )

    st.subheader("Chat Settings")
    st.session_state.max_history = st.slider(
        "Max Chat History",
        min_value=5,
        max_value=100,
        value=st.session_state.max_history,
    )

    st.session_state.show_timestamps = st.checkbox(
        "Show Timestamps",
        value=st.session_state.show_timestamps,
    )

    st.divider()

    st.subheader("📊 Session Stats")
    duration = datetime.now() - st.session_state.start_time
    st.metric("Session Duration", f"{duration.seconds // 60}m {duration.seconds % 60}s")
    st.metric("Messages Sent", len([m for m in st.session_state.messages if m["role"] == "user"]))
    st.metric("Total Messages", len(st.session_state.messages))

    st.divider()

    st.subheader("Actions")
    if st.button("🧹 Clear Chat"):
        st.session_state.messages = []

    if st.button("⬇️ Export Chat"):
        chat_export = "\n".join(
            f'{m["role"].upper()}: {m["content"]}' for m in st.session_state.messages
        )
        st.download_button(
            "Download",
            chat_export,
            file_name="chat_export.txt",
        )


# ----------------------------
# Main header
# ----------------------------
st.markdown(
    f"""
    # 🚀 {st.session_state.assistant_name}
    **Response Style:** {st.session_state.response_style}  
    **History Limit:** {st.session_state.max_history} messages
    """
)

st.info("Hello! I'm your demo assistant. How can I help you today?")


# ----------------------------
# Chat history
# ----------------------------
for msg in st.session_state.messages[-st.session_state.max_history :]:
    with st.chat_message(msg["role"]):
        if st.session_state.show_timestamps:
            st.caption(msg["time"])
        st.markdown(msg["content"])


# ----------------------------
# Chat input
# ----------------------------
user_input = st.chat_input(f"Message {st.session_state.assistant_name}...")

if user_input:
    timestamp = datetime.now().strftime("%H:%M:%S")

    st.session_state.messages.append(
        {"role": "user", "content": user_input, "time": timestamp}
    )

    # Build message history for the model
    model_messages = [
        {"role": m["role"], "content": m["content"]}
        for m in st.session_state.messages[-st.session_state.max_history :]
    ]

    # Add current user message
    model_messages.append({"role": "user", "content": user_input})

    # Call OpenAI OSS
    assistant_reply = chat(
        messages=model_messages,
        enable_reasoning=False  # set True if you want reasoning
    )

    st.session_state.messages.append(
        {"role": "assistant", "content": assistant_reply, "time": timestamp}
    )

    st.rerun()


# ----------------------------
# Expandable sections
# ----------------------------
with st.expander("ℹ️ About This Demo"):
    st.write(
        "This is a demonstration of a configurable Streamlit-based chat assistant UI. "
        "It is intended for prototyping and UI experimentation."
    )

with st.expander("🧑‍🏫 Instructor Notes"):
    st.write(
        "You can replace the assistant response logic with an LLM call, "
        "API integration, or rule-based system."
    )
