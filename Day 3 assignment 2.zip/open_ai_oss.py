from openai import OpenAI
import os

# Recommended: use environment variable for API key
API_KEY = os.getenv("OPENROUTER_API_KEY")

client = OpenAI(
    base_url="https://openrouter.ai/api/v1",
    api_key="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",
)

def chat(messages, model="openai/gpt-oss-120b", enable_reasoning=False):
    """
    messages: list of dicts [{role, content}, ...]
    returns: assistant message content (string)
    """

    extra_body = {"reasoning": {"enabled": True}} if enable_reasoning else None

    response = client.chat.completions.create(
        model=model,
        messages=messages,
        extra_body=extra_body,
    )

    return response.choices[0].message.content
